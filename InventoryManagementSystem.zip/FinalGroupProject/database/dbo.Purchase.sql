﻿CREATE TABLE [dbo].[Purchase] (
    [Id] INT NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

