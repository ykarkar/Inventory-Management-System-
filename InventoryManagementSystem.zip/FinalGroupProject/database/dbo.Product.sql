﻿CREATE TABLE [dbo].[Product] (
    [ProductID]   VARCHAR (50) NOT NULL,
    [ProductName] VARCHAR (50) NULL,
    [Price]       VARCHAR (50) NULL,
    [Category]    VARCHAR (50) NULL,
    [OrderID]     INT          NULL,
    [Status]      VARCHAR (50) NULL,
    CONSTRAINT [PK_Product] PRIMARY KEY CLUSTERED ([ProductID] ASC)
);

