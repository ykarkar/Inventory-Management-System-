﻿CREATE TABLE [dbo].[UserDet] (
    [UserID]        VARCHAR (50) NOT NULL,
    [UserName]      VARCHAR (50) NULL,
    [FullName]      VARCHAR (50) NULL,
    [EmailId]       VARCHAR (50) NULL,
    [Department]    VARCHAR (50) NULL,
    [ContactNumber] VARCHAR (50) NULL,
    [Password]      VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([UserID] ASC)
);

