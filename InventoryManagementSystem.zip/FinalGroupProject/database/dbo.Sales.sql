﻿CREATE TABLE [dbo].[Sales] (
    [OrderID]         INT          NOT NULL,
    [OrderType]       NCHAR (50)   NULL,
    [OrderDate]       DATE         NULL,
    [Description]     NCHAR (50)   NULL,
    [OrderStatus]     VARCHAR (50) NULL,
    [ProductsID]      VARCHAR (50) NULL,
    [ReceivedDate]    DATE         NULL,
    [Vendor]          VARCHAR (50) NULL,
    [ShipmentAddress] VARCHAR (50) NULL,
    [VendorContact]   VARCHAR (50) NULL,
    CONSTRAINT [PK_Sales] PRIMARY KEY CLUSTERED ([OrderID] ASC)
);

